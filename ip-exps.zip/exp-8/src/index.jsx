import reactDOM from "react-dom/client";
import App from "./App";

const root = reactDOM.createRoot(document.getElementById("root"));

root.render(<App msg="Welcome to React"/>);